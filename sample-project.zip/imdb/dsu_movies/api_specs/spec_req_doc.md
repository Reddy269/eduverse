# Movies API Specification

## APIs

### 1. Get Movies

**Endpoint**: `/movies/`
**Method**: GET

**Input Parameters**:
- `offset` (integer, optional): Starting position for pagination (default: 0)
- `limit` (integer, optional): Number of movies per page (default: 20)
- `movie_name` (string, optional): Search query for movie name

**Response Details**:

**Movies Array**: List of movie objects containing:
- Movie identifier, name, release date
- Box office collection in crores
- Creation and update timestamps

**Director Information**: For each movie includes:
- Director ID and name
- Director creation and update timestamps

**Cast Information**: Array of cast members with:
- Actor details (ID, name, timestamps)
- Character role in the movie
- Debut movie indicator

**Rating Details**: Aggregated rating data including:
- Individual rating counts (1-5 stars)
- Calculated average rating
- Total number of ratings

**Pagination Details**:
- Total count of available movies
- Current offset and limit values
- Next page availability indicator

### 2. Update Movie

**Endpoint**: `/movies/{id}/`
**Method**: PUT

**Input Parameters**:
- `id` (string, path): Movie ID (UUID)
- Request body with movie update data:
  - `name` (string, optional): Updated movie name
  - `release_date` (date, optional): Updated release date
  - `box_office_collection_in_crores` (number, optional): Updated box office collection
  - `director_id` (integer, optional): Updated director ID

**Response Details**:
- Updated movie object with complete information
- Director details
- Cast information
- Rating data
- Updated timestamps

### 3. Add Actor to Movie Cast

**Endpoint**: `/movies/{id}/actors/`
**Method**: POST

**Input Parameters**:
- `id` (string, path): Movie ID (UUID)
- Request body with cast data:
  - `actor_id` (string): Actor ID (UUID)
  - `role` (string): Character name/role
  - `is_debut_movie` (boolean, optional): Whether this is actor's debut movie

**Response Details**:
- Success message confirming actor addition
- Success status indicator

### 4. Remove Actor from Movie Cast

**Endpoint**: `/movies/{id}/actors/{actorId}/`
**Method**: DELETE

**Input Parameters**:
- `id` (string, path): Movie ID (UUID)
- `actorId` (string, path): Actor ID (UUID)

**Response Details**:
- Success message confirming actor removal
- Success status indicator

### 5. Get Movies Statistics

**Endpoint**: `/movies/stats/`
**Method**: GET

**Input Parameters**: None

**Response Details**:

**Most Popular Movies**: List of highly rated movies with:
- Movie ID, name, release date
- Box office collection
- Average rating and total ratings count

**Low Rating Movies**: List of poorly rated movies with same details

**Recently Added Movies**: List of recently added movies with same details

**Top Directors**: List of top-performing directors with:
- Director ID and name
- Average rating across their movies
- Movie count in their portfolio
- Total box office collection

**Overall Statistics**:
- Total movies count in database
- Overall average rating across all movies