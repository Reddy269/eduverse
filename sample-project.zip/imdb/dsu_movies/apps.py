from django.apps import AppConfig


class DsuMoviesAppConfig(AppConfig):
    name = "dsu_movies"

    def ready(self):
        from dsu_movies import signals # pylint: disable=unused-variable
