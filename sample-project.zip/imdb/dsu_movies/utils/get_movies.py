from django.http import HttpResponse
import json


def get_movies(search_query: str):

    response_dict = {
        "movies": [],
        "total_count": 0
    }
    return HttpResponse(content=json.dumps(response_dict), status=200)
