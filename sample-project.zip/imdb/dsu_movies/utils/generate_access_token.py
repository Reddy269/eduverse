import json

def create_user_with_email(email):
    from ib_users.interfaces.service_interface import ServiceInterface
    from ib_users.models import UserAccount

    email_user_id = UserAccount.objects.filter(email=email).values_list("pk", flat=True).first()
    if email_user_id:
        print(f"User ID: {email_user_id}")
        return email_user_id

    users_service = ServiceInterface()
    email_user_id = users_service.create_user_account_with_email(email=email)
    email_user_id = str(email_user_id)
    print(f"User ID: {email_user_id}")
    return email_user_id

def generate_access_token_for_user_id(user_id: str):
    from oauth2_provider.models import Application

    client_id = "f759194d-933e-4b76-ab63-55fe5bfab3b6"
    expiry_in_seconds = 18000

    Application.objects.get_or_create(
        client_id=client_id,
        client_type="Confidential",
        authorization_grant_type="Resource owner password-based",
        name="backend-application",
        algorithm="No OIDC support"
    )

    from ib_users.interfaces.service_interface import ServiceInterface
    users_service = ServiceInterface()
    tokens_dto = users_service.create_auth_tokens_for_user_client(
        user_id=user_id,
        expiry_in_seconds=expiry_in_seconds,
        client_id=client_id,
    )
    access_tokens_dict = {
        "access_token": tokens_dto.access_token,
        "refresh_token": tokens_dto.refresh_token,
        "expires_in": tokens_dto.expires_in
    }
    print(json.dumps(access_tokens_dict, indent=4))
    return access_tokens_dict

